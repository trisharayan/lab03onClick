package com.example.lab3onclick;

//import android.support.v7.app.AppCompatActivity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SeekBar seekBar=(SeekBar)findViewById(R.id.seekBar);

        final TextView textView1=(TextView)findViewById(R.id.mytextview1);
        final TextView textView2=(TextView)findViewById(R.id.mytextview2);
        final TextView textView3=(TextView)findViewById(R.id.mytextview3);
        final TextView textView4=(TextView)findViewById(R.id.mytextview4);



        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {



                textView1.setTextSize(16+progress/2);
                textView2.setTextSize(16+progress/2);
                textView3.setTextSize(16+progress/2);
                textView4.setTextSize(16+progress/2);


              // Toast.makeText(getApplicationContext(),"seekbar progress: "+progress, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(getApplicationContext(),"seekbar touch started!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(getApplicationContext(),"seekbar touch stopped!", Toast.LENGTH_SHORT).show();
            }



        });
    }

    @Override
    public void onClick(View view)
    {
        SharedPreferences sharedpreferences = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedpreferences.edit();




        int count;
        switch (view.getId())
        {
            case R.id.mytextview1:

                count = sharedpreferences.getInt("1",0);
                Toast.makeText(getApplicationContext(),"Text1 clicked " +(count+1)+" times",Toast.LENGTH_SHORT).show();
                editor.putInt("1", count+1);
                editor.apply();
                break;

            case R.id.mytextview2:
                count = sharedpreferences.getInt("2",0);
                Toast.makeText(getApplicationContext(),"Text2 clicked " +(count+1)+" times",Toast.LENGTH_SHORT).show();
                editor.putInt("2", count+1);
                editor.apply();
                break;

            case R.id.mytextview3:
                count = sharedpreferences.getInt("3",0);
                Toast.makeText(getApplicationContext(),"Text3 clicked " +(count+1)+" times",Toast.LENGTH_SHORT).show();
                editor.putInt("3", count+1);
                editor.apply();
                break;

            case R.id.mytextview4:
                count = sharedpreferences.getInt("4",0);
                Toast.makeText(getApplicationContext(),"Text4 clicked " +(count+1)+" times",Toast.LENGTH_SHORT).show();
                editor.putInt("4", count+1);
                editor.apply();
                break;

        }
    }




}
